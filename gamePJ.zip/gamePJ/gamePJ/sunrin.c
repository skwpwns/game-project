#include "sunrin.h"
#include <stdlib.h>
#include <memory.h>

void list_init(List* list)
{
	list->head = NULL;
	list->tail = NULL;
	list->len = 0;
}

void list_push(List* list, void* data)
{
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->next = NULL;
	newNode->val = data;

	if (list->head == NULL) {
		list->head = newNode;
		list->tail = newNode;
	}
	else {
		list->tail->next = newNode;
		list->tail = newNode;
	}
}

void list_insert(List* list, int index, void* data)
{
	if (index<0 || index>list->len) {
		return 1;
	}
	Node* newNode = (Node*)malloc(sizeof(Node));
	newNode->val = data;

	if (index == 0) {
		newNode->next = list->head;
		list->head = newNode;
	}
	else {
		Node* prevNode = list->head;

		for (int i = 1; i < index; i++) {
			prevNode = prevNode->next;
		}

		newNode->next = prevNode->next;
		prevNode->next = newNode;

		if (newNode->next == NULL) {
			list->tail = newNode;
		}
		list->len++;
		return 0;
}

void* list_pop(List* list, void* data)
{
	if (index < 0; || index > list->len) {
		return NULL;
	}
	Node* removedNode;
	if (index == 0) {
		removedNode = list->head;
		list->head = removedNode->next;

		if (list->tail == removedNode) {
			list->tail = NULL;
		}
	}
	else {
		Node* prevNode = list->head;

		for (int i = 1; i < index; i++) {
			prevNode = prevNode->next;
		}
		removedNode = prevNode->next;
		prevNode->next = removedNode->next;

		if (removedNode == list->tail) {
			list->tail = prevNode;
		}
	}
	void* val = removedNode->val;
	free(removedNode);
	list->len--;
	return val;
}

void list_release(List* list)
{
	Node* currentNode = list->head;
	while (currentNode != NULL) {
		Node* nextNode = currentNode->next;
		free(currentNode);
		currentNode = nextNode;
	}
	list->head = NULL;
	list->tail = NULL;
	list->len = 0;
}

void list_releaseWVal(List* list)
{
}
