#include "input.h"
#include <memory.h>
#include <stdlib.h>
#include <SDL.h>
// Ű���� ������ �ʿ��� �������� �����մϴ�.
size_t memSize = sizeof(Uint8) * SDL_NUM_SCANCODES;
Uint8* currentKeyState = NULL;
Uint8 beforeKeyState[SDL_NUM_SCANCODES];

// ���콺 ������ ���õ� �������� �����մϴ�.
int currentMousePosX = 0;
int currentMousePosY = 0;
Uint32 beforeMouseState = 0;
Uint32 currentMouseState = 0;

void updateKeyState()
{
	if (currentKeyState == NULL) {
		currentKeyState = SDL_GetKeyboardState(NULL);
	}

	// ������ ���, �ҽ�, ������ ũ��
	// ��� = �ҽ� * ũ��
	SDL_memcpy(beforeKeyState, currentKeyState, memSize);
}

int getKeyState(int keyCode)
{
	// KEY_NONE
	if (!beforeKeyState[keyCode] && !currentKeyState[keyCode])
		return KEY_NONE;
	// KEY_DOWN
	if (!beforeKeyState[keyCode] && currentKeyState[keyCode])
		return KEY_DOWN;
	// KEY_PRESS
	if (beforeKeyState[keyCode] && currentKeyState[keyCode])
		return KEY_PRESS;
	// KEY_UP
	if (beforeKeyState[keyCode] && !currentKeyState[keyCode])
		return KEY_UP;
}

void updateMouseState()
{
	beforeMouseState = currentMouseState;
	currentMouseState = SDL_GetMouseState(&currentMousePosX, &currentMousePosY);
}

int getButtonState(int buttonCode)
{
	Uint32 buttonMask = SDL_BUTTON(buttonCode);
	Uint32 before = beforeMouseState & buttonMask;
	Uint32 current = currentMouseState & buttonMask;

	// KEY_NONE
	if (!before && !current)
		return KEY_NONE;
	// KEY_DOWN
	if (!before && current)
		return KEY_DOWN;
	// KEY_PRESS
	if (before && current)
		return KEY_PRESS;
	// KEY_UP
	if (before && !current)
		return KEY_UP;
}

void getMousePos(int* posx, int* posy)
{
	if (posx != NULL)
		*posx = currentMousePosX;

	if (posy != NULL)
		*posy = currentMousePosY;
}
