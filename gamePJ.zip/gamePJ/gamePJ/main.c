#include <stdio.h>
#include "sunrin.h"

int main(void) {
	List list;
	list_init(&list);

	int a = 10;
	int b = 20;
	int c = 30;
	list_push(&list, &a);
	list_push(&list, &b);
	list_push(&list, &c);

	Node* cur = list.head;
	while (cur != NULL) {
		printf("%d \n", *(int*)cur->val);
		cur = cur->next;
	}
	list_release(&list);
	return 0;
}