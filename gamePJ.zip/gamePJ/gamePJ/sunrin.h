#pragma once

typedef struct node Node;
typedef struct list List;

struct node {
	Node* next;
	void* val;
};
struct list {
	Node* head;
	Node* tail;
	int len;
};

void list_init(List* list);
void list_push(List* list, void* data);
void list_insert(List* list, int index, void* data);
void* list_pop(List* list, void* data);
void list_release(List* list);
void list_releaseWVal(List* list);